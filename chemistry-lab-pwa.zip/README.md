# Chemistry Lab — Class 12 UP Board (PWA)

Hindi + Hinglish, installable Android web app with offline-first app shell.

## Features
- 10 chapter revision cards with quick notes and board-focused pointers
- Formula sheet and organic reaction bank
- 10-question MCQ quiz with instant feedback and score
- Chapter progress and saved items stored locally in the browser
- PWA manifest, icons, and service worker cache

## Publish on GitHub Pages (Android-friendly)
1. Create a GitHub repository, for example `chemistry-lab`.
2. Upload **all files and folders from this ZIP's extracted folder** into the repository root. `index.html` must be visible at the root (not inside an extra nested folder).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main`, folder `/(root)`, then tap **Save**.
6. Wait for the Pages deployment to finish. Open the URL shown in Settings → Pages (usually `https://YOUR-USERNAME.github.io/chemistry-lab/`).
7. Keep the page open online once so the service worker can cache the app shell.
8. In Chrome on Android, open the published URL → browser menu `⋮` → **Install app** or **Add to Home screen**.

## Updating
Edit files in the repository and commit/save changes. The service worker cache version is in `sw.js` (`chemistry-lab-v1`). If you make a major update and old content persists, change it to `chemistry-lab-v2`, then redeploy and reopen the website online.

## Offline notes
- App shell and built-in revision content are cached locally after first successful online load.
- Bookmarks and revision progress use localStorage on that device/browser.
- This starter has no server or cloud sync; saved progress does not automatically sync across devices.
- Installability/offline service worker requires HTTPS; GitHub Pages supplies HTTPS.
- Offline support cannot cache pages before the first successful online visit.

## Accuracy note
This is a starter revision aid, not an official UP Board publication. Verify chapter coverage and exact reactions with the current syllabus and your prescribed textbook/teacher notes. Some syllabi change, so this app intentionally presents concise revision notes rather than claiming to be an exhaustive textbook.
