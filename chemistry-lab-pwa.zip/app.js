const chapters = [
  {id:1,name:"विलयन (Solutions)",unit:"Physical",desc:"Concentration, Raoult’s law, colligative properties",topics:[
    ["मुख्य बातें",["विलयन = दो या अधिक पदार्थों का समांगी मिश्रण।","विलेय वह पदार्थ जो घुलता है; विलायक वह जिसमें घुलता है।","मोलरता ताप पर निर्भर करती है क्योंकि आयतन बदल सकता है; मोललता ताप से लगभग स्वतंत्र है।"]],
    ["जरूरी सूत्र",["Molarity (M) = solute के moles / solution का volume (L)","Molality (m) = solute के moles / solvent का mass (kg)","Mole fraction: xᵢ = nᵢ / Σn","Raoult’s law: pᵢ = xᵢ pᵢ°","ΔTᵦ = i Kᵦ m; ΔT𝒻 = i K𝒻 m","Osmotic pressure: π = i C R T"]],
    ["Board focus",["Ideal और non-ideal solutions में अंतर लिखो।","Positive/negative deviation के कारण समझो।","Van’t Hoff factor i और abnormal molar mass का अर्थ याद रखो।","Numerical में units और temperature Kelvin में रखना न भूलो।"]]
  ]},
  {id:2,name:"वैद्युत रसायन (Electrochemistry)",unit:"Physical",desc:"Cells, Nernst equation, conductivity, electrolysis",topics:[
    ["मुख्य बातें",["Oxidation anode पर और reduction cathode पर होता है।","Galvanic cell में chemical energy से electrical energy बनती है।","Cell potential positive होने पर reaction standard conditions में spontaneous होती है।"]],
    ["जरूरी सूत्र",["E°cell = E°cathode − E°anode","ΔG° = −n F E°cell","At 298 K: Ecell = E°cell − (0.0591/n) log Q","G = 1/R; conductivity κ = cell constant / R","Λₘ = κ × 1000 / C (C in mol L⁻¹)","Faraday law: m = MIt / (nF)"]],
    ["Board focus",["Nernst equation की derivation और applications।","Kohlrausch law और limiting molar conductivity।","Galvanic cell का labelled diagram; salt bridge का role।"]]
  ]},
  {id:3,name:"रासायनिक बलगतिकी (Chemical Kinetics)",unit:"Physical",desc:"Rate law, order, integrated equations, half-life",topics:[
    ["मुख्य बातें",["Reaction rate concentration के समय के साथ बदलने की दर है।","Order rate law में concentration powers का योग है; इसे experiment से निकाला जाता है।","Molecularity elementary step के reacting species की संख्या है।"]],
    ["जरूरी सूत्र",["Rate = k[A]ᵐ[B]ⁿ; overall order = m+n","Zero order: [A]ₜ = [A]₀ − kt; t½ = [A]₀/(2k)","First order: k = (2.303/t) log([A]₀/[A]ₜ)","First order half-life: t½ = 0.693/k","Arrhenius: k = A e^(−Ea/RT)","log(k₂/k₁) = Ea/(2.303R) × (1/T₁ − 1/T₂)"]],
    ["Board focus",["Zero और first order के graphs पहचानो।","Order और molecularity में अंतर।","Rate constant की units order के अनुसार बदलती हैं।"]]
  ]},
  {id:4,name:"d- एवं f-ब्लॉक तत्व",unit:"Inorganic",desc:"Electronic configuration, trends, KMnO₄, K₂Cr₂O₇",topics:[
    ["मुख्य बातें",["Transition elements में atom या common ion के d-subshell में partially filled orbitals होते हैं।","Variable oxidation states, coloured ions, complex formation और catalytic activity सामान्य गुण हैं।","Lanthanoid contraction, lanthanoids में atomic/ionic radii की gradual decrease है।"]],
    ["याद रखने योग्य",["KMnO₄ acidic medium में प्रबल oxidising agent है।","K₂Cr₂O₇ acidic medium में Cr(VI) से Cr(III) में reduce हो सकता है।","Zn, Cd और Hg सामान्य transition-element definition के अपवाद माने जाते हैं क्योंकि इनके d orbitals पूर्ण भरे होते हैं।"]],
    ["Board focus",["Transition metals के गुणों के कारण।","Lanthanoid contraction के परिणाम।","KMnO₄ और K₂Cr₂O₇ की redox reactions textbook से practice करो।"]]
  ]},
  {id:5,name:"समन्वय यौगिक (Coordination Compounds)",unit:"Inorganic",desc:"Ligands, coordination number, nomenclature, isomerism",topics:[
    ["मुख्य बातें",["Central metal atom/ion से जुड़े ions या molecules को ligands कहते हैं।","Coordination number = central metal से सीधे जुड़े donor atoms की संख्या।","Ligands monodentate, bidentate या polydentate हो सकते हैं।"]],
    ["Quick examples",["[Co(NH₃)₆]Cl₃ में coordination entity [Co(NH₃)₆]³⁺ है।","[Pt(NH₃)₂Cl₂] में square-planar geometry के कारण cis-trans isomerism संभव है।","Oxidation number निकालते समय पूरे complex का कुल charge balance करो।"]],
    ["Board focus",["IUPAC naming और formula writing।","Werner theory, VBT/CFT के basic ideas।","Geometrical और optical isomerism; magnetic behaviour।"]]
  ]},
  {id:6,name:"हैलोऐल्केन तथा हैलोऐरीन",unit:"Organic",desc:"SN1/SN2, preparation, reactions, uses",topics:[
    ["मुख्य बातें",["Haloalkanes में halogen sp³ carbon से और haloarenes में aromatic ring carbon से जुड़ा होता है।","SN1 में carbocation intermediate; SN2 में one-step backside attack होता है।","Aryl halides में C–X bond resonance के कारण अपेक्षाकृत मजबूत होता है।"]],
    ["महत्वपूर्ण reactions",["R–X + aq. KOH → R–OH + KX","R–X + alc. KOH, heat → alkene + KX + H₂O (elimination)","2R–X + 2Na → R–R + 2NaX (Wurtz; dry ether)","Ar–N₂⁺Cl⁻ + CuCl/HCl → Ar–Cl + N₂ (Sandmeyer type)"]],
    ["Board focus",["SN1 और SN2 की तुलना।","Haloarenes की कम reactivity के कारण।","Named reactions, conversions और reaction conditions।"]]
  ]},
  {id:7,name:"ऐल्कोहॉल, फीनॉल एवं ईथर",unit:"Organic",desc:"Acidity, dehydration, oxidation, Williamson synthesis",topics:[
    ["मुख्य बातें",["Alcohol में –OH saturated carbon से जुड़ा होता है; phenol में –OH सीधे aromatic ring से जुड़ा होता है।","Phenol, alcohol से अधिक acidic है क्योंकि phenoxide ion resonance-stabilised होता है।","Ethers का general structure R–O–R′ है।"]],
    ["महत्वपूर्ण reactions",["R–OH + Na → R–ONa + ½H₂","Alcohol dehydration: alcohol —conc. H₂SO₄/heat→ alkene + H₂O","Williamson synthesis: RONa + R′X → ROR′ + NaX","Phenol + Br₂(aq) → 2,4,6-tribromophenol (white precipitate)"]],
    ["Board focus",["Phenol की acidity और electrophilic substitution।","Alcohol oxidation products; primary/secondary/tertiary distinction।","Williamson synthesis और ether cleavage।"]]
  ]},
  {id:8,name:"ऐल्डिहाइड, कीटोन एवं कार्बोक्सिलिक अम्ल",unit:"Organic",desc:"Nucleophilic addition, tests, oxidation and reduction",topics:[
    ["मुख्य बातें",["Aldehyde group –CHO; ketone group >C=O; carboxylic acid group –COOH।","Aldehydes generally ketones से अधिक reactive होते हैं nucleophilic addition में।","Carboxylic acids की acidity carboxylate ion के resonance stabilisation से जुड़ी है।"]],
    ["महत्वपूर्ण reactions",["Aldehyde + Tollens’ reagent → silver mirror (सामान्य test)","Aldehyde + Fehling’s solution → कई aliphatic aldehydes में brick-red Cu₂O","R–CHO + [O] → R–COOH","R–COOH + R′OH ⇌ R–COOR′ + H₂O (acid catalyst)"]],
    ["Board focus",["Aldol और Cannizzaro reactions की conditions।","Tollens’, Fehling’s और iodoform tests की limitations।","Conversions, acidity order और reaction mechanisms।"]]
  ]},
  {id:9,name:"ऐमीन (Amines)",unit:"Organic",desc:"Basicity, diazonium salts, preparation and reactions",topics:[
    ["मुख्य बातें",["Amines ammonia के derivatives हैं जिनमें एक या अधिक H atoms alkyl/aryl groups से replace होते हैं।","Basicity lone pair की availability और solvent/structure पर निर्भर करती है।","Aniline में lone pair benzene ring के साथ resonance में जाता है, इसलिए यह aliphatic amines से कम basic है।"]],
    ["महत्वपूर्ण reactions",["R–NH₂ + HCl → R–NH₃⁺Cl⁻","Aniline + NaNO₂/HCl, 273–278 K → benzene diazonium chloride","Diazonium salts से azo coupling द्वारा coloured azo dyes बन सकते हैं।"]],
    ["Board focus",["Hinsberg test का basic purpose।","Diazotisation और diazonium salt conversions।","Amines की basicity order को context सहित याद करो।"]]
  ]},
  {id:10,name:"जैव-अणु (Biomolecules)",unit:"Organic",desc:"Carbohydrates, proteins, enzymes, vitamins, nucleic acids",topics:[
    ["मुख्य बातें",["Carbohydrates polyhydroxy aldehydes/ketones या hydrolysis पर ऐसे compounds देने वाले पदार्थ हैं।","Proteins amino acids के peptide bonds से बने polymers हैं।","DNA और RNA nucleic acids हैं; nucleotide में sugar, nitrogenous base और phosphate होता है।"]],
    ["Quick revision",["Glucose एक aldohexose है; fructose एक ketohexose है।","Peptide bond: –CO–NH–","Denaturation से protein की higher structure/biological activity प्रभावित होती है।","Vitamins को water-soluble और fat-soluble groups में classify किया जाता है।"]],
    ["Board focus",["Reducing/non-reducing sugars।","Protein structure, enzymes और denaturation।","DNA vs RNA और vitamin deficiency facts textbook से revise करो।"]]
  ]}
];

const formulas = [
  {title:"विलयन",formula:"M = n/V(L) ·  m = n/solvent mass(kg) ·  π = iCRT",note:"ΔTb = iKbm और ΔTf = iKfm; temperature Kelvin में लें."},
  {title:"वैद्युत रसायन",formula:"E°cell = E°cathode − E°anode ·  ΔG° = −nFE°cell",note:"298 K पर E = E° − (0.0591/n) log Q."},
  {title:"चालकता",formula:"G = 1/R ·  κ = cell constant/R ·  Λm = κ × 1000/C",note:"Λm वाले formula में C mol L⁻¹ में हो."},
  {title:"रासायनिक बलगतिकी",formula:"First order: k = (2.303/t) log(a/(a−x)) ·  t½ = 0.693/k",note:"First-order k की unit time⁻¹ होती है."},
  {title:"Arrhenius equation",formula:"k = A e^(−Ea/RT)",note:"T Kelvin में; Ea और R की units consistent रखें."},
  {title:"Faraday law",formula:"m = MIt/(nF)",note:"F ≈ 96485 C mol⁻¹; n electron transfer count है."}
];

const reactions = [
  {title:"Alcohol → Alkene",formula:"R–CH₂–CH₂OH  —conc. H₂SO₄, heat→  alkene + H₂O",note:"Dehydration; product conditions और substrate पर depend करता है."},
  {title:"Williamson ether synthesis",formula:"RONa + R′X → R–O–R′ + NaX",note:"Primary alkyl halides आम तौर पर बेहतर SN2 substrates हैं."},
  {title:"Wurtz reaction",formula:"2R–X + 2Na  —dry ether→  R–R + 2NaX",note:"Symmetrical alkanes के लिए useful; mixed halides mixtures दे सकते हैं."},
  {title:"Fischer esterification",formula:"RCOOH + R′OH ⇌ RCOOR′ + H₂O",note:"Acid catalyst और equilibrium reaction."},
  {title:"Tollens’ test",formula:"Aldehyde + Tollens’ reagent → silver mirror (often)",note:"Ketones generally negative; कुछ special compounds exceptions हो सकते हैं."},
  {title:"Diazotisation",formula:"ArNH₂ + NaNO₂ + 2HCl → ArN₂⁺Cl⁻ + NaCl + 2H₂O",note:"0–5°C (273–278 K) के आसपास."},
  {title:"Phenol bromination",formula:"C₆H₅OH + 3Br₂(aq) → 2,4,6-C₆H₂Br₃OH + 3HBr",note:"White precipitate of 2,4,6-tribromophenol."}
];

const questions = [
 {q:"Molarity की SI-style common unit कौन-सी है?",opts:["mol kg⁻¹","mol L⁻¹","g mol⁻¹","mol s⁻¹"],a:1,e:"Molarity = moles of solute / volume of solution in litres."},
 {q:"Galvanic cell में oxidation कहाँ होता है?",opts:["Cathode","Salt bridge","Anode","दोनों electrodes पर हमेशा"],a:2,e:"Oxidation anode पर होता है; reduction cathode पर."},
 {q:"First-order reaction के rate constant की unit है:",opts:["mol L⁻¹ s⁻¹","s⁻¹","L mol⁻¹ s⁻¹","mol² L⁻²"],a:1,e:"First-order k की unit time⁻¹ होती है, जैसे s⁻¹."},
 {q:"Phenol alcohol से अधिक acidic क्यों है?",opts:["Mass कम है","Phenoxide ion resonance-stabilised है","इसमें oxygen नहीं होता","यह non-polar है"],a:1,e:"Phenoxide ion का resonance stabilisation acidity बढ़ाता है."},
 {q:"SN1 reaction में सामान्य intermediate क्या है?",opts:["Carbanion","Free radical","Carbocation","Carbene"],a:2,e:"SN1 mechanism में leaving group के निकलने पर carbocation बनता है."},
 {q:"Peptide bond किस प्रकार का linkage है?",opts:["–CO–NH–","–O–O–","–COO–","–N=N–"],a:0,e:"Amino acids peptide bond (–CO–NH–) से जुड़ते हैं."},
 {q:"Coordination number का अर्थ है:",opts:["Complex का कुल charge","Metal से सीधे जुड़े donor atoms की संख्या","Ligand का mass","Oxidation state हमेशा"],a:1,e:"Donor atoms की संख्या गिनी जाती है, केवल ligands की संख्या नहीं."},
 {q:"Glucose को सामान्यतः क्या classify करते हैं?",opts:["Ketohexose","Aldopentose","Aldohexose","Aminosugar"],a:2,e:"Glucose में aldehyde functional group और छह carbon होते हैं."},
 {q:"E°cell किसके बराबर है?",opts:["E°anode − E°cathode","E°cathode − E°anode","E°anode + resistance","Current × time"],a:1,e:"Cell potential = cathode reduction potential minus anode reduction potential."},
 {q:"Van’t Hoff factor को किससे denote करते हैं?",opts:["k","i","n","π"],a:1,e:"i solute particles की effective संख्या में बदलाव को दर्शाता है."}
];

const STORAGE = {revised:"chemLabRevisedV1", saved:"chemLabSavedV1"};
let revised = new Set(JSON.parse(localStorage.getItem(STORAGE.revised) || "[]"));
let saved = new Set(JSON.parse(localStorage.getItem(STORAGE.saved) || "[]"));
let activeChapter = null;
let quizIndex = 0, score = 0, answered = false;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function persist(){localStorage.setItem(STORAGE.revised,JSON.stringify([...revised]));localStorage.setItem(STORAGE.saved,JSON.stringify([...saved]));updateProgress();}
function updateProgress(){
 const count=revised.size, total=chapters.length;
 $("#progressBar").style.width=(count/total*100)+"%";
 $("#progressText").textContent=`${count}/${total} chapters revised`;
}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2100);}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function showView(name){
 $$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
 $$(".view").forEach(v=>v.classList.toggle("active",v.id==="view-"+name));
 if(name==="saved")renderSaved();
}
function renderChapters(filter=""){
 const list=$("#chapterList");const filtered=chapters.filter(c=>(c.name+" "+c.desc+" "+c.unit).toLowerCase().includes(filter.toLowerCase()));
 if(!filtered.length){list.innerHTML='<div class="empty">Koi chapter nahi mila.</div>';return;}
 list.innerHTML=filtered.map(c=>`<article class="chapter-card"><div class="card-top"><span class="chapter-no">CHAPTER ${String(c.id).padStart(2,"0")}</span><span class="tag">${escapeHTML(c.unit)}</span></div><h3>${escapeHTML(c.name)}</h3><p>${escapeHTML(c.desc)}</p><div class="card-bottom"><span class="${revised.has(c.id)?'done':''}">${revised.has(c.id)?"✓ Revised":"Revision pending"}</span><button class="open-btn" data-open="${c.id}">Open notes →</button></div></article>`).join("");
 list.querySelectorAll("[data-open]").forEach(b=>b.addEventListener("click",()=>openChapter(Number(b.dataset.open))));
}
function openChapter(id){
 activeChapter=chapters.find(c=>c.id===id);if(!activeChapter)return;
 $("#dialogTag").textContent=`CHAPTER ${String(id).padStart(2,"0")} · ${activeChapter.unit}`;
 $("#dialogTitle").textContent=activeChapter.name;
 $("#dialogBody").innerHTML=activeChapter.topics.map(([heading,items])=>`<h3>${escapeHTML(heading)}</h3><ul>${items.map(i=>`<li>${escapeHTML(i)}</li>`).join("")}</ul>`).join("")+`<p class="small-note">Exam tip: definitions, conditions, units aur balanced equations ko written practice mein zaroor likho.</p>`;
 $("#bookmarkChapter").textContent=saved.has("c"+id)?"★ Saved for revision":"☆ Save for revision";
 $("#markRevised").textContent=revised.has(id)?"Revised ✓":"Mark revised ✓";
 $("#chapterDialog").showModal();
}
function renderFormulas(){
 $("#formulaList").innerHTML=formulas.map((f,i)=>`<article class="content-card"><h3>${escapeHTML(f.title)}</h3><div class="formula">${escapeHTML(f.formula)}</div><p>${escapeHTML(f.note)}</p><div class="inline-actions"><button class="secondary" data-save="f${i}">${saved.has("f"+i)?"★ Saved":"☆ Save formula"}</button></div></article>`).join("");
 $("#formulaList").querySelectorAll("[data-save]").forEach(b=>b.addEventListener("click",()=>toggleSaved(b.dataset.save)));
}
function renderReactions(){
 $("#reactionList").innerHTML=reactions.map((r,i)=>`<article class="content-card"><h3>${escapeHTML(r.title)}</h3><div class="formula">${escapeHTML(r.formula)}</div><p>${escapeHTML(r.note)}</p><div class="inline-actions"><button class="secondary" data-save="r${i}">${saved.has("r"+i)?"★ Saved":"☆ Save reaction"}</button></div></article>`).join("");
 $("#reactionList").querySelectorAll("[data-save]").forEach(b=>b.addEventListener("click",()=>toggleSaved(b.dataset.save)));
}
function toggleSaved(key){if(saved.has(key)){saved.delete(key);toast("Saved list se hata diya");}else{saved.add(key);toast("Revision ke liye save ho gaya ✓");}persist();renderFormulas();renderReactions();renderChapters($("#searchInput").value);renderSaved();if(activeChapter)$("#bookmarkChapter").textContent=saved.has("c"+activeChapter.id)?"★ Saved for revision":"☆ Save for revision";}
function renderSaved(){
 const items=[];
 saved.forEach(key=>{
  if(key.startsWith("c")){const c=chapters.find(x=>x.id===Number(key.slice(1)));if(c)items.push({key,title:c.name,desc:"Chapter notes",action:()=>openChapter(c.id)});}
  else if(key.startsWith("f")){const f=formulas[Number(key.slice(1))];if(f)items.push({key,title:f.title,desc:f.formula,action:()=>showView("formulas")});}
  else if(key.startsWith("r")){const r=reactions[Number(key.slice(1))];if(r)items.push({key,title:r.title,desc:r.formula,action:()=>showView("reactions")});}
 });
 const list=$("#savedList");
 if(!items.length){list.innerHTML='<div class="empty">Abhi kuch save nahi hai. Chapter, formula ya reaction par ☆ tap karo.</div>';return;}
 list.innerHTML=items.map(i=>`<article class="content-card"><h3>${escapeHTML(i.title)}</h3><p>${escapeHTML(i.desc)}</p><div class="inline-actions"><button class="open-btn" data-open-saved="${escapeHTML(i.key)}">Open</button><button class="secondary" data-remove="${escapeHTML(i.key)}">Remove</button></div></article>`).join("");
 list.querySelectorAll("[data-open-saved]").forEach(b=>b.addEventListener("click",()=>{const k=b.dataset.openSaved;if(k.startsWith("c"))openChapter(Number(k.slice(1)));else showView(k.startsWith("f")?"formulas":"reactions");}));
 list.querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>toggleSaved(b.dataset.remove)));
}
function renderQuestion(){
 answered=false;const q=questions[quizIndex];
 $("#quizCounter").textContent=`Question ${quizIndex+1}/${questions.length}`;$("#quizScore").textContent=`Score: ${score}`;
 $("#nextQuestion").disabled=true;$("#nextQuestion").textContent=quizIndex===questions.length-1?"See result →":"Next question →";
 $("#quizCard").innerHTML=`<h3>${quizIndex+1}. ${escapeHTML(q.q)}</h3><div class="options">${q.opts.map((o,i)=>`<button class="option" data-option="${i}">${String.fromCharCode(65+i)}. ${escapeHTML(o)}</button>`).join("")}</div><div id="feedback"></div>`;
 $("#quizCard").querySelectorAll("[data-option]").forEach(b=>b.addEventListener("click",()=>answerQuestion(Number(b.dataset.option))));
}
function answerQuestion(index){
 if(answered)return;answered=true;const q=questions[quizIndex];if(index===q.a)score++;
 $("#quizCard").querySelectorAll("[data-option]").forEach((b,i)=>{b.disabled=true;if(i===q.a)b.classList.add("correct");if(i===index&&i!==q.a)b.classList.add("wrong");});
 $("#feedback").innerHTML=`<div class="feedback">${index===q.a?"Correct! ✓":"Correct answer: "+String.fromCharCode(65+q.a)} — ${escapeHTML(q.e)}</div>`;
 $("#quizScore").textContent=`Score: ${score}`;$("#nextQuestion").disabled=false;
}
function nextQuestion(){
 if(!answered)return;
 if(quizIndex===questions.length-1){$("#quizCard").innerHTML=`<h3>Test complete! 🎉</h3><p>You scored ${score}/${questions.length}.</p><p class="small-note">${score>=8?"Great revision!":"Answers dobara revise karke test repeat karo."}</p>`;$("#quizCounter").textContent="Completed";$("#nextQuestion").disabled=true;return;}
 quizIndex++;renderQuestion();
}
$$(".tab").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$("#searchInput").addEventListener("input",e=>renderChapters(e.target.value));
$("#closeDialog").addEventListener("click",()=>$("#chapterDialog").close());
$("#bookmarkChapter").addEventListener("click",()=>{if(activeChapter)toggleSaved("c"+activeChapter.id);});
$("#markRevised").addEventListener("click",()=>{if(!activeChapter)return;if(revised.has(activeChapter.id)){revised.delete(activeChapter.id);toast("Revision status reset");}else{revised.add(activeChapter.id);toast("Chapter revised ✓");}persist();renderChapters($("#searchInput").value);$("#markRevised").textContent=revised.has(activeChapter.id)?"Revised ✓":"Mark revised ✓";});
$("#nextQuestion").addEventListener("click",nextQuestion);
$("#restartQuiz").addEventListener("click",()=>{quizIndex=0;score=0;renderQuestion();});
function updateNetwork(){const online=navigator.onLine;$("#networkStatus").textContent=online?"Online · latest app assets available":"Offline mode · saved app content available";$(".status").classList.toggle("online",online);}
window.addEventListener("online",updateNetwork);window.addEventListener("offline",updateNetwork);
let deferredPrompt=null;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("#installBtn").hidden=false;});
$("#installBtn").addEventListener("click",async()=>{if(!deferredPrompt){toast("Browser menu → Add to Home screen use karo.");return;}deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("#installBtn").hidden=true;});
window.addEventListener("appinstalled",()=>toast("Chemistry Lab installed ✓"));
renderChapters();renderFormulas();renderReactions();renderQuestion();updateProgress();updateNetwork();
if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
